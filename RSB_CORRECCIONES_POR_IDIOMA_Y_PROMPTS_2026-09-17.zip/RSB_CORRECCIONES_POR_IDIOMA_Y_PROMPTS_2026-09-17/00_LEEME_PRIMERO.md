# RSB — PAQUETE DE CORRECCIONES POR IDIOMA Y PROMPTS

Fecha: 2026-09-17

## Fuente auditada
`RSB_WEB_REPO_FINAL_CORREGIDO_REAUDITADO_2026-09-15(5).zip`

SHA-256:
`d56b58ef93fe93e1c5dd4f61b2abfe164329e14c5841c5719f08cecfa8c143a4`

Inventario:
- 317 archivos
- 200 HTML
- 20 grupos × 10 idiomas
- 398 incidencias de dimensiones
- 198 HTML afectados
- 19 imágenes físicas implicadas

## Estructura
- `00_FUENTES/`: ZIP original y documentos enviados por el propietario.
- `00_COMPARTIDO/`: datos canónicos, 398 incidencias, 19 imágenes, hashes y decisiones operativas.
- `01_EN_Ingles/` ... `10_PL_Polski/`: 20 HTML del idioma, correcciones y prompt exacto.

## Decisiones del propietario incorporadas
- 226 reseñas es el valor canónico.
- La Google Maps API key está restringida.
- Reserva: 30% transferencia + 70% al recoger.
- Depósito scooter de referencia: 250 €.
- Sin depósito para bicicletas, patines en línea, patines clásicos, skateboards y longboards.
- Radio: 25 km.
- No se ofrecen e-scooters ni e-bikes.

## Uso
Para corregir un idioma:
1. Sube este ZIP completo a un chat nuevo.
2. Abre el archivo `05_PROMPT_NUEVO_CHAT_<IDIOMA>.txt` de la carpeta del idioma.
3. Copia y pega ese prompt literalmente.
4. El chat debe trabajar sobre una extracción fresca del ZIP original de `00_FUENTES/`, tocar solo las 20 rutas autorizadas y devolver únicamente esos 20 HTML corregidos con informe y hashes.

## Nota
Las copias de `PAGINAS_REPO/` son referencias aisladas byte a byte. La fuente de código para hacer cambios sigue siendo el ZIP original incluido en `00_FUENTES/`.
